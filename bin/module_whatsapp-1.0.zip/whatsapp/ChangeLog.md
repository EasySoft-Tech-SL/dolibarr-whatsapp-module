# CHANGELOG WHATSAPP FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.0

Initial version
