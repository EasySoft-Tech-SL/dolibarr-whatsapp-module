INSERT INTO `llx_c_actioncomm` (`id`, `code`, `type`, `libelle`, `module`, `active`, `todo`, `color`, `picto`, `position`) 
VALUES 
(9182, 'AC_SEND_WHATSAPP', 'module', 'ActionAC_SEND_WHATSAPP', NULL, 1, NULL, NULL, NULL, 1),
(9183, 'AC_SEND_WHATSAPP_AUDIO', 'module', 'ActionSEND_WHATSAPP_AUDIO', NULL, 1, NULL, NULL, NULL, 2),
(9184, 'AC_SEND_WHATSAPP_PDF', 'module', 'ActionSEND_WHATSAPP_PDF', NULL, 1, NULL, NULL, NULL, 3),
(9185, 'AC_RECEIVE_WHATSAPP', 'module', 'ActionAC_RECEIVE_WHATSAPP', NULL, 1, NULL, NULL, NULL, 4);
(9186, 'AC_SEND_WHATSAPP_NOTIFY', 'module', 'ActionAC_SEND_WHATSAPP_NOTIFY', NULL, 1, NULL, NULL, NULL, 4);
